# Two Brain Regions, One Dataset, and What a Gene Can Tell You About Fear

*I spent three weeks staring at a spreadsheet of brain data. Here is what I found — and why it changed how I think about neuroscience.*

---

There is a question that has bothered me for a long time: how does the brain decide what to remember?

Not in a vague, philosophical sense — I mean the actual mechanics of it. When something frightening happens, the memory of it tends to stick. When something routine happens, it often doesn't. Why? What is the brain doing differently in those two cases, at the level of molecules and cells?

I started looking into this and kept running into two structures: the **hippocampus** and the **amygdala**. They sit next to each other deep in the brain, they've been studied together for decades, and they are almost opposites in what they do.

The hippocampus forms memories. The amygdala processes fear. And somehow, when the amygdala fires — when something emotionally significant happens — it amplifies hippocampal memory formation, which is why you can remember exactly where you were on the day something terrible happened, but not what you had for lunch last Tuesday.

I wanted to understand this from the inside. Not just the *what* — what these regions do — but the *how*. What is actually different about the hippocampus and amygdala at the molecular level that makes them capable of such different things?

---

## The dataset that made this possible

A few years ago, a project called the **Allen Human Brain Atlas** did something remarkable. Researchers took post-mortem human brains, sliced them into thousands of tiny samples, measured which genes were being expressed in each sample, and mapped every single measurement back to a standardized 3D brain atlas. Then they made the whole thing free to download.

The result is one of the richest open datasets in neuroscience. You can go to brain-map.org right now, type in the name of any gene, and see a color-coded map of the human brain showing you where that gene is most active. Warmer colors mean higher expression. The brain lights up differently for every gene you search.

I spent about an hour just clicking through genes before I wrote a single line of code. BDNF, a protein involved in learning, blazes bright in the hippocampus. CRH, a stress hormone, concentrates in the amygdala. It is genuinely beautiful in the way that only data can be.

---

## What I actually did

I chose eight genes to study, selected because they represent two different functional worlds:

**The memory world:** BDNF (brain-derived neurotrophic factor, which supports synaptic plasticity), CAMK2A (an enzyme that gets physically activated when a synapse strengthens during learning), and GRIN2B (a subunit of the NMDA receptor, the molecular switch that allows memories to form).

**The fear and stress world:** CRH (the hormone that kicks off the body's stress response), NPY (a neuropeptide that acts as a natural anxiety suppressant), and SLC6A4 (the gene that encodes the serotonin transporter — the same protein targeted by most antidepressants).

And two structural genes — GAD1 (which makes GABA, the brain's main inhibitory neurotransmitter) and APOE (a major Alzheimer's risk gene involved in lipid transport) — that I predicted would show similar expression in both regions, as a kind of control.

I pulled expression energy values for each gene across eight subregions: four parts of the hippocampus (CA1, CA3, the dentate gyrus, and the subiculum) and four nuclei of the amygdala (the basolateral, central, lateral, and medial nuclei). Then I made four figures and spent a long time thinking about what I was looking at.

---

## What I found

The heatmap I produced is one of the clearest results I have ever generated from data. The hippocampal rows and the amygdalar rows look almost nothing alike — except for the two structural genes, which stay consistent across both.

BDNF's highest expression in the entire dataset occurs in the **dentate gyrus** — not CA1, not CA3, but specifically the dentate gyrus. This is significant because the dentate gyrus is one of only two regions in the adult human brain where neurogenesis — the birth of brand new neurons — continues throughout life. BDNF promotes the survival and integration of those new neurons. The data is pointing at something real: the region with the highest rate of ongoing structural change is also the region expressing the most of the protein that drives that change.

CRH tells an equally precise story. Its peak expression is in the **central nucleus** of the amygdala (8.6 out of 10). The central nucleus is not just any part of the amygdala — it is the amygdala's main output station. It is the structure that sends signals to the brainstem to produce the physical fear response: the racing heart, the frozen muscles, the hyperventilation. The gene encoding the stress hormone that initiates all of this is most concentrated in the exact subregion most responsible for producing it.

That is the part that stayed with me. This is not correlation. This is the molecular mechanism of fear, visible in a spreadsheet.

---

## The number that surprised me most

When I calculated the log₂ fold change — a standard way of measuring how much more expressed a gene is in one region versus another — CRH came back at **−2.93**.

In practical terms, that means CRH is expressed roughly **7.5 times more** in amygdalar tissue than in hippocampal tissue.

By comparison, BDNF's hippocampal enrichment is log₂FC = +1.83, which is about a 3.5-fold difference. Both are large. But the amygdala's grip on CRH is extraordinary.

And then there are GAD1 and APOE, sitting at log₂FC = −0.10 and +0.03 respectively — essentially zero. The brain maintains the same level of inhibitory neurotransmitter synthesis and lipid transport infrastructure in both regions, regardless of how different everything else is. That makes sense: some things are just housekeeping.

---

## What this changed for me

Before this project, I understood the hippocampus and amygdala the way you understand things from textbooks — abstractly, correctly, but not really deeply. I knew the definitions. I could explain the functions.

After three weeks of actually working with the data, I understand them differently. I understand them the way you understand something you've seen for yourself.

The brain's functional specialization is not a metaphor. It is not just a way of describing behavior. It is written in molecules — in which proteins a region's cells are actively manufacturing at any given moment. The hippocampus is a memory machine because its cells are full of BDNF and CaMKII and NMDA receptors. The amygdala is a fear detector because its cells are full of CRH and serotonin transporters.

The function is the expression. The expression is the function.

---

## Limitations I thought about

I want to be honest about what this analysis cannot tell you, because I think scientific honesty is as important as scientific enthusiasm.

The Allen Brain Atlas measures bulk gene expression — RNA levels averaged across millions of cells from many different types. Excitatory neurons, inhibitory neurons, astrocytes, and microglia are all pooled together. A more sophisticated analysis would use single-cell RNA sequencing to ask which specific cell types are expressing each gene. That technology exists; I just didn't use it here.

The data also comes from post-mortem adult brain tissue from six donors. Gene expression is not static — it changes with age, with experience, with stress, with disease. What I measured is a snapshot of a few individuals at one point in time, not a universal constant.

These limitations do not invalidate the findings. But they are real, and naming them is part of doing science properly.

---

## What I'd do next

If I had access to a lab, I would want to look at this in two directions.

First, I would want to see how these expression profiles change in clinical populations — people with PTSD, with Alzheimer's disease, with major depression. SLC6A4 variants are associated with PTSD susceptibility; does SLC6A4 expression in the amygdala differ between PTSD patients and healthy controls? The AHBA data doesn't answer this, but other open datasets might.

Second, I would want to go deeper into the amygdala's internal organization. The central nucleus and the basolateral complex are not just anatomically distinct — they play different roles in fear learning and fear extinction. I would want to characterize their gene expression profiles separately and see whether the molecular differences between them map onto their functional differences as clearly as the hippocampus-amygdala difference does.

---

## Where to find everything

All of my code, figures, and the full written report are available on GitHub: **[github.com/YOUR_USERNAME/allen-brain-atlas-project]**

The notebook runs in Google Colab with no installation required. The data is free. If you want to replicate or extend this analysis, everything you need is there.

If you have questions, or if you see something I got wrong, I would genuinely like to know. That is how this gets better.

---

*Elif Yılmaz is an independent researcher with a background in linguistics and cognitive science, currently building a portfolio in neuroscience and biology. This project was completed using open-access data from the Allen Human Brain Atlas.*
