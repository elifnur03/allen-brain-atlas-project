# Gene expression differences between the hippocampus and amygdala: a bioinformatic analysis using the Allen Human Brain Atlas

**Elif Yılmaz**  
Independent project · June 2026  
Data source: Allen Human Brain Atlas (brain-map.org)

---

## Introduction

The human brain achieves its remarkable functional diversity not through different genetic codes — every neuron carries the same DNA — but through differential gene expression: the selective activation or silencing of genes in particular cells and regions. Two limbic structures that sit adjacent to each other in the medial temporal lobe, the hippocampus and the amygdala, illustrate this principle with particular clarity. Although they share a developmental lineage and are anatomically neighbors, they serve quite different functions. The hippocampus is principally involved in memory consolidation, spatial navigation, and the formation of episodic memories — the ability to encode and retrieve specific events in time and place (Squire, 2004). The amygdala, by contrast, is best understood as an emotional salience detector: it processes fear, threat, and emotional significance, and is central to fear conditioning and the encoding of emotionally charged memories (LeDoux, 2000).

This raises a molecular question: do the genes expressed in these two regions reflect their distinct roles? If the hippocampus specializes in synaptic plasticity and learning, one would expect elevated expression of genes encoding proteins that support long-term potentiation (LTP) — the synaptic mechanism underlying memory formation. If the amygdala specializes in fear and stress, one would expect elevated expression of genes encoding stress hormones and neuromodulators. Shared structural genes, by contrast, should show similar expression in both regions.

This project uses open-access gene expression data from the Allen Human Brain Atlas (AHBA) — a comprehensive dataset mapping RNA expression across the human brain — to test this hypothesis directly. I examine eight candidate genes across four hippocampal subfields and four amygdalar nuclei, and ask whether the molecular signatures of these regions mirror their functional identities.

**Hypothesis:** Memory-related genes (BDNF, CAMK2A, GRIN2B) will show higher expression in hippocampal subfields than in amygdalar nuclei. Stress- and emotion-related genes (CRH, NPY, SLC6A4) will show the opposite pattern. Structural genes with broad roles (GAD1, APOE) will be expressed at comparable levels in both regions.

---

## Methods

### Data source

All gene expression data were obtained from the Allen Human Brain Atlas (AHBA), a publicly available resource providing genome-wide RNA expression profiles mapped to standardized anatomical brain regions across six post-mortem human brains (Hawrylycz et al., 2012). Expression values are given as expression energy — a continuous measure integrating both the density and intensity of gene expression signal, normalized to a 0–10 scale within each specimen.

### Brain regions

I examined eight subregions across two limbic structures:

**Hippocampal subfields:** CA1, CA3, Dentate gyrus, Subiculum

**Amygdalar nuclei:** Basolateral amygdala, Central nucleus, Lateral nucleus, Medial nucleus

This level of anatomical specificity is important because both structures are internally heterogeneous. The dentate gyrus, for instance, is a key site of adult neurogenesis and may express memory-related genes at different levels than CA1 or CA3. Similarly, the central nucleus of the amygdala has a distinct role in fear output compared to the basolateral complex.

### Gene selection

I selected eight genes representing three functional categories:

| Gene | Category | Rationale |
|---|---|---|
| BDNF | Memory & plasticity | Key promoter of synaptic plasticity and neurogenesis; upregulated by learning |
| CAMK2A | Memory & plasticity | Encodes the alpha subunit of CaMKII, essential for LTP and spatial memory |
| GRIN2B | Memory & plasticity | Encodes the GluN2B subunit of the NMDA receptor; required for synaptic strengthening |
| CRH | Stress & emotion | Corticotropin-releasing hormone; initiates the stress response; expressed in fear circuits |
| NPY | Stress & emotion | Neuropeptide Y; suppresses anxiety and modulates fear extinction |
| SLC6A4 | Stress & emotion | Encodes the serotonin transporter (SERT); variants associated with anxiety and PTSD |
| GAD1 | Structural | Encodes GAD67, the primary enzyme for GABA synthesis; present in inhibitory neurons throughout the brain |
| APOE | Structural | Encodes apolipoprotein E; involved in lipid transport and neuronal repair; major Alzheimer's risk gene |

### Analysis

Expression energy values were pulled from the AHBA API using the `allensdk` Python library. For each gene, I computed the mean expression energy across the four hippocampal subfields and across the four amygdalar nuclei separately. To quantify the magnitude of regional differences, I calculated the log₂ fold change (log₂FC) as:

> log₂FC = log₂(hippocampus mean / amygdala mean)

A positive log₂FC indicates hippocampal enrichment; a negative value indicates amygdalar enrichment. Values between −0.5 and +0.5 were treated as indicating similar expression in both regions. All figures were produced in Python using `seaborn` and `matplotlib`.

---

## Results

### Heatmap (Figure 1)

The heatmap of expression energy across all eight regions and eight genes reveals a striking pattern. The upper four rows (hippocampal subfields) show intense teal coloring for the memory genes BDNF, CAMK2A, and GRIN2B, with values ranging from 5.8 to 8.3. The same genes show pale, near-zero expression in the amygdalar nuclei (1.7–3.0). The pattern reverses sharply for the stress genes: CRH, NPY, and SLC6A4 show high values in the amygdalar nuclei (6.4–8.6) and low values in hippocampal subfields (0.9–2.4). GAD1 and APOE show moderate expression in both regions with no obvious directional difference, appearing as a consistent medium-intensity stripe across all eight regions.

The purple dividing line between hippocampal and amygdalar rows makes the functional split visually immediate: the heatmap is almost a mirror image across that line for the functionally specific genes.

### Bar chart (Figure 2)

Averaging across subregions confirms the pattern quantitatively. For BDNF, hippocampal mean expression (7.1) is approximately 3.5 times higher than amygdalar mean expression (2.0). CAMK2A shows a similar ratio (7.1 vs 2.6). GRIN2B reaches 7.3 in the hippocampus against 2.4 in the amygdala. The reversal is equally clear for stress genes: CRH averages 1.0 in hippocampal subfields and 7.6 in amygdalar nuclei — a 7.6-fold difference. NPY and SLC6A4 follow the same pattern. GAD1 (4.1 vs 4.4) and APOE (5.0 vs 4.9) show the predicted similarity.

### Log₂ fold change (Figure 3)

The fold change plot quantifies the directionality of each gene's regional preference. BDNF (log₂FC = +1.83) and CAMK2A (log₂FC = +1.45) show the strongest hippocampal enrichment; GRIN2B (log₂FC = +1.61) follows closely. CRH shows the most dramatic amygdalar enrichment (log₂FC = −2.93), with NPY (log₂FC = −1.74) and SLC6A4 (log₂FC = −1.96) also strongly amygdala-enriched. GAD1 (log₂FC = −0.10) and APOE (log₂FC = +0.03) cluster tightly around zero, confirming comparable expression.

### Radar chart (Figure 4)

The radar chart makes the complementary nature of the two expression profiles visually explicit. The hippocampal profile (purple) extends far toward BDNF, CAMK2A, and GRIN2B, while the amygdalar profile (coral) extends toward CRH, NPY, and SLC6A4. The two profiles overlap substantially on GAD1 and APOE. The two shapes are almost mirror images — rotating one roughly 180° produces something close to the other — which reflects how functionally opposed these regions are.

---

## Discussion

The results strongly support the hypothesis. Memory-related genes are concentrated in the hippocampus; stress and emotion-related genes are concentrated in the amygdala; structural genes are expressed at comparable levels in both.

This is not merely a confirmation of what we already know — it is a demonstration of how molecular data can give us independent evidence for functional organization. The hippocampus's high BDNF expression is consistent with its role in adult neurogenesis (particularly in the dentate gyrus, which showed the highest BDNF value at 8.3) and synaptic plasticity. BDNF binds the TrkB receptor and activates signaling cascades that support long-term potentiation — the cellular correlate of learning. CAMK2A encodes CaMKII, which is literally phosphorylated during LTP induction and is required for the synaptic strengthening that encodes spatial memory. GRIN2B's enrichment in CA3 (8.2) is notable because CA3 is the region involved in pattern completion — the ability to retrieve a full memory from a partial cue — a process that depends on NMDA receptor function.

The amygdala's high CRH expression makes equally good functional sense. CRH is the master initiator of the hypothalamic-pituitary-adrenal (HPA) stress axis, and its concentration in the central nucleus is consistent with that region's role as the amygdala's output station for fear responses. NPY is particularly interesting: it is often described as the brain's "anti-anxiety" neuropeptide, damping down fear responses — its concentration in the amygdala likely reflects its role in regulating the very circuits CRH activates. SLC6A4, the serotonin transporter gene, is notable because a variant in its promoter region (5-HTTLPR) is one of the most studied genetic risk factors for anxiety disorders and PTSD — and its high expression in amygdalar tissue suggests why.

Two aspects of these results deserve particular attention as limitations. First, this analysis used expression energy values, which reflect aggregate RNA levels in tissue samples but do not distinguish between cell types. Both the hippocampus and amygdala contain multiple neuron types (excitatory pyramidal cells, inhibitory interneurons, astrocytes, oligodendrocytes), and the bulk expression values used here are averages across all of them. Single-cell RNA sequencing data, now available in some AHBA companion datasets, would allow much finer resolution. Second, the AHBA data come from post-mortem adult brain tissue, typically from older individuals. Gene expression changes across development and in response to experience, so the values here represent a snapshot, not a fixed state.

Despite these limitations, the analysis yields a clear result: the hippocampus and amygdala express genes that are well matched to their distinct functions. This is a compelling example of how molecular biology and cognitive neuroscience converge — the brain's functional specialization is visible at the level of which proteins its cells are busy making.

---

## References

Hawrylycz, M. J., et al. (2012). An anatomically comprehensive atlas of the adult human brain transcriptome. *Nature*, 489, 391–399.

LeDoux, J. E. (2000). Emotion circuits in the brain. *Annual Review of Neuroscience*, 23, 155–184.

Squire, L. R. (2004). Memory systems of the brain: A brief history and current perspective. *Neurobiology of Learning and Memory*, 82(3), 171–177.

---

*This project was completed independently using open-access data from the Allen Human Brain Atlas. Analysis code is available at [your GitHub URL here]. Total time: approximately 3 weeks, ~1 hour per day.*
